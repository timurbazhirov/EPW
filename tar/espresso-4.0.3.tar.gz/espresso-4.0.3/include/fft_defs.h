
#define C_POINTER integer*8
