# Configurations on maximum number of kinds and maximum value for IOTK_MAXRANK
 nkinds=4
 maxrank=7

