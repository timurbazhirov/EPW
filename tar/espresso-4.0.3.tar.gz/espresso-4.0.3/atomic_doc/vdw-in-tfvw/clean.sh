rm -r results
